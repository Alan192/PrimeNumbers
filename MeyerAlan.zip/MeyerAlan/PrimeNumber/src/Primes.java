public class Primes{
	//Array qui sera utilisé pour stocker les nombres premiers
	//private pour empêcher sa modification en dehors de cette Classe
	private int[] confirmed;
	
	//Array en lecture seule
	public int[] getConfirmed() {
		return confirmed;
	}
	
	//à part 2 il n'existe pas d'autre nombre premiers qui sont des chiffres pairs, cette méthode nous aide à les éliminer
	public static boolean isOdd(int input) {
		return ((input % 2 != 0) ? true : false);
	}
	
	//méthode vérifiant si un nombre est premier, renvoyant "true" quand c'est le cas
	public static boolean isPrime(int tested) {
		//2 est le plus petit nombre premier, on renvoie donc "true" si on teste 2 (à cause de la méthode isOdd qui l'ignorerait) 
		//et on renvoie "false" si on teste un nombre plus petit.
		if (tested == 2) return true;
		if (tested < 2) return false;
		
		//si notre nombre testé est impair...
		if(isOdd(tested)) {
			//on vérifie qu'il est premier
			for(int i = 3; i<=(tested / i); i += 2) {
				if(tested % i == 0) return false;
			}
			return true;
		}
		//nombre pair -> false
		return false;
	}
	
	//cette méthode utilise la précédente pour stocker les nombres premiers dans notre Array
	public void rangePrime(int end) throws NegativeIntegerException {
		//si la quantité de nombre premiers demandée est négative, on lance une exception
		if(end <= 0) {
			throw new NegativeIntegerException();
		}
		//instantiation de l'Array, maintenant qu'on connait la taille dont on aura besoin
		confirmed = new int[end];
		int current = 0;
		//"tested" est l'entier que nous testerons
		int tested = 0;
		//boucle qui s'arrètera à la fin de l'array (current = index courrant | end = index de fin de l'array)
		while(current < end) {
			//appel de la méthode vérifiant la primalité
			if(isPrime(tested)) {
				confirmed[current] = tested;
				current ++;
			}
			//on passe à l'entier suivant
			tested++;
		}
	}
	
	
	
}
