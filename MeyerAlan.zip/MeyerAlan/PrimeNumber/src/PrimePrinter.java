import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class PrimePrinter {
	
	BufferedWriter writer;
	
	//Cette méthode reçoit le chemin du fichier visé sous forme de String et instancie le "BufferedWriter" qui ira écrire dedans
	public void initiateWriter(String filePath) throws IOException {
		writer = new BufferedWriter(new FileWriter(filePath));
	}
	
	//Cette méthode écrit une simple String grâce au Writer précédemment instancié
	public void printString(String content) throws IOException {	    
		writer.write(content + "\n");
	}
	
	//Cette méthode écrira les détails d'un array d'integer
	//Elle reçoit "desc", une description de ce que contient l'array et l'array en question
	public void printArrayOfInt(String desc, int[] array) throws IOException{
		int index = 1;
		for(int item : array) {
			//Le résultat sera notre description, l'index de l'élèment et enfin l'élèment, le tout formaté pour être lisible
			writer.write(desc + index + ": " + item + "\n");
			index++;
		}
	}
	
	//Fonction à appeler en fin d'écriture.
	public void endPrinting() throws IOException {
		writer.close();
	}
}
