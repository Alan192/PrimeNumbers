
public class NegativeIntegerException extends Exception {

	public NegativeIntegerException() {
		//ici le message de retour de l'exception est modifié, pour pouvoir déclencher l'erreur et afficher un message parlant à l'utilisateur
		super("Veuillez rentrer un entier positif s'il vous plait.");
	}

	public NegativeIntegerException(String message) {
		super(message);
	}

	public NegativeIntegerException(Throwable cause) {
		super(cause);
	}

	public NegativeIntegerException(String message, Throwable cause) {
		super(message, cause);
	}

	public NegativeIntegerException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
