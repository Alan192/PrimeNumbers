import java.util.concurrent.TimeUnit;

public class TimeConverter {

	//Méthode renvoyant un String égal à la durée reçue (en millisecondes) convertie en secondes.
	public String MilliToSeconds(long span) {
		long seconds = TimeUnit.MILLISECONDS.toSeconds(span);
		//toSeconds a arrondit la valeur en secondes, par souci de précision on récupère les chiffres après la virgule par cette soustraction
		long milliseconds = span - TimeUnit.SECONDS.toMillis(seconds);

	    return seconds + "." + milliseconds;
	}
}
