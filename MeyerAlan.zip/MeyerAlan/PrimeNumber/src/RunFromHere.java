import java.io.IOException;
import java.util.Scanner;

//Equivalent de la classe "Test" dans les exercices, on y retrouve le main
public class RunFromHere {

	public static void main(String[] args){
		int input = 0;
		boolean flag = true;
		
		TimeConverter tc = new TimeConverter();
		
		//cette boucle est ici pour l'input utilisateur, que j'ai rajouté pour avoir une gestion d'exceptions dans le programme.
		//On vérifie que c'est bel et bien un entier
		do{
			//le Scanner nous permettra de capter l'input utilisateur
			Scanner myScan = new Scanner(System.in);
			System.out.println("Combien de nombres premiers voulez-vous trouver?");
			
			try {
				//on vérifie que l'input utilisateur est bel est bien un integer 
				if(myScan.hasNextInt()) {
					//si oui on inscrit sa valeur dans input et on rend le flag "false" pour sortir de la boucle
					input = myScan.nextInt();
					flag = false;
				//si non on lance l'exception prévue
				}else throw new WrongInputException();
			}
			catch(WrongInputException e) {
				//Cette exception sera levée si l'input utilisateur n'est pas un entier
				//Le feedback utilisateur sera un simple message dans la console, le message modifié de notre exception
				System.out.println(e.getMessage());
			}
		}while(flag);
		
		//lancement du chronomètre, l'input utilisateur n'a pas besoin de s'y trouver.
		long startingTime = System.currentTimeMillis();
		
		//j'initialise ici les objets en rapport avec le calcul et affichage des nombres premiers, la seule raison étant
		//que je souhaitais le faire durant le chronomètre.
		Primes mc = new Primes();
		PrimePrinter printer = new PrimePrinter();

		//Ici l'exception sera levée quand l'entier rentré par l'utilisateur est négatif.
		//L'idée était d'avoir une fonction dans une autre classe qui renvoie une exception, pour avoir une gestion différente de la précédente
		//Il serait par contre judicieux de gérer cette exception elle aussi à l'entrée user
		try {
			mc.rangePrime(input);
		} catch (NegativeIntegerException e) {
			//Ici on affiche tout les détails de l'erreur, idée de la gérer différemment de la précédente.
			//Le message par défaut est lui aussi modifié dans le constructeur pour donner une idée claire de la raison du crash.
			e.printStackTrace();
		}
		
		//Ici le programme écrit les nombres premiers trouvés dans un fichier "résultat.txt"
	    try {
			printer.initiateWriter("resultat.txt");
			
			printer.printArrayOfInt("nombre premier n°", mc.getConfirmed());
		    
		} catch (IOException e) {
			//Affichage d'un message parlant pour l'utilisateur
			System.out.println("Un probleme est survenu en tentant d'écrire dans le fichier");
			e.printStackTrace();
		}
	    
	    //Calcul du temps pris, le temps relevé à la fin moins le temps relevé au début
		long endTime = System.currentTimeMillis();
		long span = (endTime - startingTime);

		//on utilise la méthode de notre classe "TimeConverter" pour afficher le temps en secondes et non en millisecondes
	    String dureeCalcul = "Durée du calcul:" + tc.MilliToSeconds(span) + " secondes";
	    
	    //On écrit le temps pris dans le fichier, il faut utiliser le même Writer ou il écrasera les données déjà inscrites
	    try {
			printer.printString(dureeCalcul);
			
		    printer.endPrinting();
		} catch (IOException e) {
			//Affichage d'un message parlant pour l'utilisateur
			System.out.println("Un probleme est survenu en tentant d'écrire dans le fichier");
			e.printStackTrace();
		}
	    
	    //affichage du temps pris dans la console
		System.out.println(dureeCalcul);
		
	}

}
